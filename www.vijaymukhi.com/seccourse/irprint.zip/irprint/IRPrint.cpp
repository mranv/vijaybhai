#include <eikapp.h>
#include <eikdoc.h>
#include <eikappui.h>
#include <eikbctrl.h>
#include <eikenv.h>
#include <e32std.h>
#include <ckninfo.h>
#include <stringloader.h>
#include <cknenv.h>
#include <Etel3rdParty.h>
#include <es_sock.h>
#include <in_sock.h>
#include <c32comm.h>
#include "f32file.h"

static const TUid KUidHelloWorldBasicApp = {0x10001000};
class zCEikApplication : public CEikApplication
{
public:
TUid AppDllUid() const;
CApaDocument* CreateDocumentL();
};
class zCEikDocument : public CEikDocument
{
public:
CEikAppUi* CreateAppUiL();
zCEikDocument( CEikApplication& aApp );
};
class zCEikBorderedControl : public CEikBorderedControl
    {
    public:
        void Draw( const TRect& aRect ) const;
        zCEikBorderedControl(const TRect& aRect);
    };
class zCEikAppUi : public CEikAppUi
    {
    public:
        void ConstructL();
        zCEikAppUi();
        void HandleCommandL( TInt aCommand );
void DialNumberL( const TDesC& aPhoneNumber );

    };
TUid zCEikApplication::AppDllUid() const
{
return KUidHelloWorldBasicApp;
}
void zCEikAppUi::ConstructL()
{
BaseConstructL();
new zCEikBorderedControl( ClientRect() );
}
LOCAL_C void doExampleL()
{
const TTimeIntervalMicroSeconds32 KTimeOut(4000000);
User::LoadPhysicalDevice(_L("EUART1"));
User::LoadPhysicalDevice(_L("ECOMM"));
StartC32();
RCommServ server;
server.Connect();
server.LoadCommModule(_L("IrCOMM"));
RComm commPort;
commPort.Open(server,_L("IrCOMM::0"),ECommExclusive);
TRequestStatus status;
commPort.Write(status,KTimeOut,_L8("Vijay Mukhi and Sonal Mukhi\r\n"));
User::WaitForRequest(status);
commPort.Write(status,KTimeOut,_L8("IR Printed using my code"));
User::WaitForRequest(status);
commPort.Close();
server.Close();
}
void zCEikAppUi::HandleCommandL( TInt aCommand )
{
if ( aCommand == EEikCmdExit)
CBaActiveScheduler::Exit();
if ( aCommand == 1)
{
CCknInfoDialog::RunDlgLD(_L("Start Printing"),_L("Choose OK"));
doExampleL();
}
}
zCEikBorderedControl::zCEikBorderedControl(const TRect& aRect)
{
CreateWindowL();
SetRect( aRect );
ActivateL();
}
void zCEikBorderedControl::Draw( const TRect& aRect ) const
{
CWindowGc& gc = SystemGc();
gc.UseFont( iCoeEnv->NormalFont() );
_LIT( aa,"Printing using Infra Red" );
gc.DrawText( aa, TPoint( 30,130 ) );
}
GLDEF_C TInt E32Dll( TDllReason /*aReason*/ )
{
return KErrNone;
}
EXPORT_C CApaApplication* NewApplication() 
{
return ( new zCEikApplication );
}
CApaDocument* zCEikApplication::CreateDocumentL()
{  
return (new zCEikDocument(*this));
}
zCEikDocument::zCEikDocument( CEikApplication& aApp ) : CEikDocument( aApp ) 
{
}
CEikAppUi* zCEikDocument::CreateAppUiL()
{
return (new zCEikAppUi);
}
zCEikAppUi::zCEikAppUi()                              
{
}
