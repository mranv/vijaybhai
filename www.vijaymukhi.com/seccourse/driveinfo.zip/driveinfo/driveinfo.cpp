#include <eikapp.h>
#include <eikdoc.h>
#include <eikappui.h>
#include <eikbctrl.h>
#include <eikenv.h>
#include <ckninfo.h>
#include <stringloader.h>
#include <cknenv.h>
#include <f32file.h>
static const TUid KUidHelloWorldBasicApp = {0x10001001};
class zCEikApplication : public CEikApplication
{
public:
TUid AppDllUid() const;
CApaDocument* CreateDocumentL();
};
class zCEikDocument : public CEikDocument
{
public:
CEikAppUi* CreateAppUiL();
zCEikDocument( CEikApplication& aApp );
};
class zCEikBorderedControl : public CEikBorderedControl
    {
    public:
        void Draw( const TRect& aRect ) const;
        zCEikBorderedControl(const TRect& aRect);
    };
class zCEikAppUi : public CEikAppUi
    {
    public:
        void ConstructL();
        zCEikAppUi();
        void HandleCommandL( TInt aCommand );
    };
TUid zCEikApplication::AppDllUid() const
{
return KUidHelloWorldBasicApp;
}
void zCEikAppUi::ConstructL()
{
BaseConstructL();
new zCEikBorderedControl( ClientRect() );
}
void zCEikAppUi::HandleCommandL( TInt aCommand )
{
if ( aCommand == 1)
{
RFs fsSession;
fsSession.Connect();
TInt driveNumber=EDriveA; 
TChar driveLetter; 
TBuf<1024>aa;
TDriveList drivelist; 
fsSession.DriveList(drivelist);
aa.Copy(_L("Valid drives are "));
for (driveNumber=EDriveA; driveNumber<=EDriveZ;driveNumber++)
{
if (drivelist[driveNumber]) 
{
fsSession.DriveToChar(driveNumber,driveLetter);
aa.Append(driveLetter);
aa.Append(' ');
}
}
CCknInfoDialog::RunDlgLD(_L("Drives"),aa);
TBuf<200> buffer;
TDriveInfo driveInfo; 
for (driveNumber=EDriveA; driveNumber<=EDriveZ; driveNumber++)
{
fsSession.Drive(driveInfo,driveNumber);
if (driveInfo.iDriveAtt==KDriveAbsent)
continue;
buffer.Format(_L("iType=%02x iBattery=%02x\niDriveAtt=%02x iMediaAtt=%02x\n"), driveInfo.iType,driveInfo.iBattery,driveInfo.iDriveAtt,driveInfo.iMediaAtt);
if (driveInfo.iBattery == EBatLow)
buffer.Append(_L("Battery Low\n"));
if (driveInfo.iBattery == EBatGood)
buffer.Append(_L("Battery Good\n"));
switch (driveInfo.iType)
{
case EMediaNotPresent:
buffer.Append(_L("No Media present\n"));             
break;
case EMediaFloppy:
buffer.Append(_L("Media is Floppy Disk Drive\n"));             
break;
case EMediaHardDisk: 
buffer.Append(_L("Media is hard Disk Drive\n"));             
break;
case EMediaCdRom:
buffer.Append(_L("Media is a CDROM drive\n"));             
break;
case EMediaRam:
buffer.Append(_L("Media is RAM memory\n"));             
break;
case EMediaFlash:
buffer.Append(_L("Media is Flash Memory\n"));             
break;
case EMediaRom:
buffer.Append(_L("Media is ROM memory\n"));             
break;
case EMediaRemote:
buffer.Append(_L("Media is Remote\n"));
break;
default:
buffer.Append(_L("Unknown New media cause for concern\n"));             
}
buffer.Append(_L("Drive Attributes are \n"));
if (driveInfo.iDriveAtt & KDriveAttLocal)
buffer.Append(_L(" local "));
if (driveInfo.iDriveAtt & KDriveAttRom)
buffer.Append(_L(" ROM "));
if (driveInfo.iDriveAtt & KDriveAttRedirected)
buffer.Append(_L(" redirected "));
if (driveInfo.iDriveAtt & KDriveAttSubsted)
buffer.Append(_L(" substituted "));
if (driveInfo.iDriveAtt & KDriveAttInternal)
buffer.Append(_L(" internal "));
if (driveInfo.iDriveAtt & KDriveAttRemovable)
buffer.Append(_L(" removable "));

buffer.Append(_L("\nMedia Attributes \n"));
if (driveInfo.iMediaAtt & KMediaAttVariableSize)
buffer.Append(_L(" Dynamic "));
if (driveInfo.iMediaAtt & KMediaAttDualDensity)
buffer.Append(_L(" DualDensity "));
if (driveInfo.iMediaAtt & KMediaAttFormattable)
buffer.Append(_L(" Formattable "));
if (driveInfo.iMediaAtt & KMediaAttWriteProtected)
buffer.Append(_L(" WriteProtected "));

aa.Copy(_L("For Drive "));
fsSession.DriveToChar(driveNumber,driveLetter);
aa.Append(driveLetter);
CCknInfoDialog::RunDlgLD(aa , buffer);
buffer.Zero();
TVolumeInfo volumeInfo;
TInt err=fsSession.Volume(volumeInfo,driveNumber);
if (err!=KErrNotReady) 
{
buffer.Copy(_L("\nVolume Information\n"));
buffer.AppendFormat(_L("Volume name %S\n"),&volumeInfo.iName);
buffer.AppendFormat(_L("Unique ID %x\n"),volumeInfo.iUniqueID);
buffer.AppendFormat(_L("Free Space %d\n"),volumeInfo.iFree/1024);
buffer.AppendFormat(_L("Max Space %d "),volumeInfo.iSize/1024);
CCknInfoDialog::RunDlgLD(aa , buffer);
}
buffer.Zero();
}
fsSession.Close();
}
else
CBaActiveScheduler::Exit();
}
zCEikBorderedControl::zCEikBorderedControl(const TRect& aRect)
{
CreateWindowL();
SetRect( aRect );
ActivateL();
}
void zCEikBorderedControl::Draw( const TRect& aRect ) const
{
CWindowGc& gc = SystemGc();
gc.UseFont( iCoeEnv->NormalFont() );
_LIT( aa,"Drive Information" );
gc.DrawText( aa, TPoint( 30,130 ) );
}
GLDEF_C TInt E32Dll( TDllReason /*aReason*/ )
{
return KErrNone;
}
EXPORT_C CApaApplication* NewApplication() 
{
return ( new zCEikApplication );
}
CApaDocument* zCEikApplication::CreateDocumentL()
{  
return (new zCEikDocument(*this));
}
zCEikDocument::zCEikDocument( CEikApplication& aApp ) : CEikDocument( aApp ) 
{
}
CEikAppUi* zCEikDocument::CreateAppUiL()
{
return (new zCEikAppUi);
}
zCEikAppUi::zCEikAppUi()              
{
}
